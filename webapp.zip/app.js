// المتغيرات العامة
let players = [];
let currentRound = 0;
let currentPlayerIndexInRound = 0;
let gameActive = true;
let answered = false;
let timerInterval;
let timeLeft = 15;
let currentQuestion = null;
let currentCorrectAnswerText = "";
const QUESTIONS_PER_PLAYER = 10;

function getPlayerType(age) {
    if (age >= 10 && age <= 15) return "easy";
    if (age >= 16 && age <= 25) return "medium";
    return "hard";
}

// إدارة اللاعبين
function showAddForm() {
    document.getElementById('addForm').style.display = 'block';
}

function cancelAddPlayer() {
    document.getElementById('addForm').style.display = 'none';
    document.getElementById('playerName').value = '';
    document.getElementById('playerAge').value = '';
}

function confirmAddPlayer() {
    const name = document.getElementById('playerName').value.trim();
    const age = parseInt(document.getElementById('playerAge').value);
    if (!name) {
        alert("❌ يرجى كتابة اسم اللاعب!");
        return;
    }
    if (isNaN(age)) {
        alert("❌ يرجى كتابة العمر!");
        return;
    }
    if (age < 10) {
        alert("❌ العمر يجب أن يكون 10 سنوات أو أكثر!");
        return;
    }
    if (age > 70) {
        alert("❌ العمر يجب أن يكون 70 سنة أو أقل!");
        return;
    }
    if (players.length >= 10) {
        alert("❌ الحد الأقصى 10 لاعبين!");
        return;
    }
    players.push({
        name: name,
        age: age,
        score: 0,
        type: getPlayerType(age),
        questionsAnswered: 0
    });
    cancelAddPlayer();
    renderPlayersList();
}

function renderPlayersList() {
    const list = document.getElementById('playersList');
    if (players.length === 0) {
        list.innerHTML = '<div style="text-align: center; padding: 40px; color: #94A3B8;">👥 لا يوجد لاعبين<br>اضغط على "➕ إضافة لاعب"</div>';
    } else {
        const sortedForDisplay = [...players].sort((a, b) => b.age - a.age);
        list.innerHTML = "";
        sortedForDisplay.forEach((p) => {
            const originalIndex = players.findIndex(orig => orig.name === p.name && orig.age === p.age);
            const div = document.createElement("div");
            div.className = "player-card";
            div.innerHTML = `
                <div class="player-info">
                    <div class="player-avatar">${p.name.charAt(0)}</div>
                    <div>
                        <div class="player-name">${p.name}</div>
                        <div class="player-age">${p.age} سنة</div>
                    </div>
                </div>
                <button class="delete-btn" onclick="removePlayer(${originalIndex})">🗑️</button>
            `;
            list.appendChild(div);
        });
    }
    const enterBtn = document.getElementById('enterGameBtn');
    if (players.length >= 2) {
        enterBtn.disabled = false;
        enterBtn.style.opacity = '1';
    } else {
        enterBtn.disabled = true;
        enterBtn.style.opacity = '0.5';
    }
}

function removePlayer(index) {
    players.splice(index, 1);
    renderPlayersList();
}

function sortPlayersByAgeDesc() {
    players.sort((a, b) => b.age - a.age);
}

// دوال اللعبة
function startGame() {
    if (players.length < 2) {
        alert("❌ يجب إضافة لاعبين على الأقل!");
        return;
    }
    sortPlayersByAgeDesc();
    players.forEach(p => {
        p.score = 0;
        p.questionsAnswered = 0;
    });
    for (let type in questionBank) {
        questionBank[type].forEach(q => { q.used = false; });
    }
    currentRound = 0;
    currentPlayerIndexInRound = 0;
    gameActive = true;
    document.getElementById('setupScreen').style.display = 'none';
    document.getElementById('gameScreen').style.display = 'block';
    loadQuestion();
}

function shuffleOptions(question) {
    if (!question.options) return question;
    const optionsWithFlag = question.options.map((opt, idx) => ({
        text: opt,
        isCorrect: (idx === question.answer)
    }));
    for (let i = optionsWithFlag.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [optionsWithFlag[i], optionsWithFlag[j]] = [optionsWithFlag[j], optionsWithFlag[i]];
    }
    let newCorrectIndex = -1;
    const newOptions = optionsWithFlag.map((item, idx) => {
        if (item.isCorrect) newCorrectIndex = idx;
        return item.text;
    });
    return {
        q: question.q,
        options: newOptions,
        correctAnswerText: question.options[question.answer],
        correctIndex: newCorrectIndex
    };
}

function loadQuestion() {
    if (!gameActive) return;
    if (timerInterval) clearInterval(timerInterval);
    answered = false;
    timeLeft = 15;
    const currentPlayer = players[currentPlayerIndexInRound];
    document.getElementById('progress').innerHTML = `الجولة ${currentRound + 1} من ${QUESTIONS_PER_PLAYER}`;
    document.getElementById('playerNameDisplay').innerHTML = `🎮 ${currentPlayer.name}`;
    document.getElementById('timer').innerHTML = timeLeft;
    document.getElementById('message').innerHTML = "";
    let questions = [...questionBank[currentPlayer.type]];
    const availableQuestions = questions.filter(q => !q.used);
    if (availableQuestions.length === 0) {
        questionBank[currentPlayer.type].forEach(q => { q.used = false; });
        questions = [...questionBank[currentPlayer.type]];
    }
    const filteredQuestions = questions.filter(q => !q.used);
    const randomIndex = Math.floor(Math.random() * filteredQuestions.length);
    let selectedQuestion = { ...filteredQuestions[randomIndex] };
    const originalQuestion = questionBank[currentPlayer.type].find(q => q.q === selectedQuestion.q);
    if (originalQuestion) originalQuestion.used = true;
    const shuffled = shuffleOptions(selectedQuestion);
    currentQuestion = shuffled;
    currentCorrectAnswerText = shuffled.correctAnswerText;
    document.getElementById('question').innerHTML = currentQuestion.q;
    const optionsDiv = document.getElementById('options');
    optionsDiv.innerHTML = "";
    currentQuestion.options.forEach((opt, idx) => {
        const btn = document.createElement('button');
        btn.className = 'option-btn';
        btn.innerHTML = opt;
        btn.onclick = () => checkAnswer(opt, idx);
        optionsDiv.appendChild(btn);
    });
    timerInterval = setInterval(() => {
        if (!answered && timeLeft > 0 && gameActive) {
            timeLeft--;
            document.getElementById('timer').innerHTML = timeLeft;
            if (timeLeft === 0) {
                clearInterval(timerInterval);
                if (!answered && gameActive) {
                    answered = true;
                    document.getElementById('message').innerHTML = "⏰ انتهى الوقت! لا نقطة 😢";
                    document.getElementById('message').style.color = "#EF4444";
                    disableOptions();
                }
            }
        }
    }, 1000);
}

function checkAnswer(selectedOptionText, selectedIndex) {
    if (answered || !gameActive) return;
    answered = true;
    clearInterval(timerInterval);
    const isCorrect = (selectedOptionText === currentCorrectAnswerText);
    const options = document.querySelectorAll('.option-btn');
    let correctOptionIndex = -1;
    for (let i = 0; i < currentQuestion.options.length; i++) {
        if (currentQuestion.options[i] === currentCorrectAnswerText) {
            correctOptionIndex = i;
            break;
        }
    }
    if (isCorrect) {
        players[currentPlayerIndexInRound].score++;
        document.getElementById('message').innerHTML = "✅ إجابة صحيحة! +1 نقطة";
        document.getElementById('message').style.color = "#10B981";
        if (options[selectedIndex]) options[selectedIndex].classList.add('correct');
    } else {
        document.getElementById('message').innerHTML = `❌ خطأ! الإجابة الصحيحة: ${currentCorrectAnswerText}`;
        document.getElementById('message').style.color = "#EF4444";
        if (options[selectedIndex]) options[selectedIndex].classList.add('wrong');
        if (options[correctOptionIndex]) options[correctOptionIndex].classList.add('correct');
    }
    disableOptions();
}

function disableOptions() {
    const options = document.querySelectorAll('.option-btn');
    options.forEach(opt => { opt.style.pointerEvents = 'none'; });
}

function nextTurn() {
    if (!answered && timeLeft > 0 && gameActive) {
        alert("يرجى الإجابة على السؤال أولاً!");
        return;
    }
    if (!gameActive) return;
    players[currentPlayerIndexInRound].questionsAnswered++;
    currentPlayerIndexInRound++;
    if (currentPlayerIndexInRound >= players.length) {
        currentRound++;
        currentPlayerIndexInRound = 0;
        if (currentRound >= QUESTIONS_PER_PLAYER) {
            endGame();
            return;
        }
    }
    loadQuestion();
}

function endGame() {
    gameActive = false;
    clearInterval(timerInterval);
    document.getElementById('gameScreen').style.display = 'none';
    showResultsScreen();
}

function showResultsScreen() {
    const sortedPlayers = [...players].sort((a, b) => b.score - a.score);
    const winner = sortedPlayers[0];
    const isTie = sortedPlayers.length > 1 && sortedPlayers[0].score === sortedPlayers[1].score;
    const resultsHTML = `
        <div class="winner-card">
            <div class="trophy-icon">${isTie ? "🤝" : "🏆"}</div>
            <div class="winner-name">${isTie ? "تعادل!" : winner.name}</div>
            <div style="font-size: 18px;">${isTie ? `${winner.score} نقطة لكل منهما` : `${winner.score} نقطة`}</div>
        </div>
        <div class="card">
            <h3 style="margin-bottom: 16px;">📊 النتائج النهائية</h3>
            <div class="score-list">
                ${sortedPlayers.map((player, idx) => {
                    let medal = "";
                    if (idx === 0 && !isTie) medal = "🥇";
                    else if (idx === 1 && !isTie) medal = "🥈";
                    else if (idx === 2 && !isTie) medal = "🥉";
                    else medal = `${idx + 1}.`;
                    return `
                        <div class="score-row">
                            <span class="rank">${medal}</span>
                            <span>${player.name}</span>
                            <span style="font-weight: 700; color: #6366F1;">${player.score} نقطة</span>
                        </div>
                    `;
                }).join('')}
            </div>
            <button onclick="restartFromResults()" class="btn-primary" style="margin-top: 16px;">🔄 العب مرة أخرى</button>
        </div>
    `;
    document.getElementById('resultsScreen').style.display = 'block';
    document.getElementById('resultsScreen').innerHTML = resultsHTML;
}

function restartFromResults() {
    players.forEach(p => {
        p.score = 0;
        p.questionsAnswered = 0;
    });
    currentRound = 0;
    currentPlayerIndexInRound = 0;
    gameActive = true;
    for (let type in questionBank) {
        questionBank[type].forEach(q => { q.used = false; });
    }
    document.getElementById('resultsScreen').style.display = 'none';
    document.getElementById('setupScreen').style.display = 'block';
    renderPlayersList();
}

// بدء التشغيل
renderPlayersList();