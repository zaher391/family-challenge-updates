// ========== بنك الأسئلة (مضمن بالكامل) ==========
const questionBank = {
    easy: [
        {q: "كم عدد أرجل الكلب؟ 🐶", options: ["2","3","4"], answer: 2},
        {q: "ما لون الموز الناضج؟ 🍌", options: ["أخضر","أصفر","أحمر"], answer: 1},
        {q: "ماذا يقول الديك؟ 🐓", options: ["موو","كوكو","هيها"], answer: 1},
        {q: "كم عدد أيام الأسبوع؟", options: ["5","6","7"], answer: 2},
        {q: "ما أكبر حيوان بري؟ 🐘", options: ["زرافة","فيل","أسد"], answer: 1},
        {q: "كم أرجل العنكبوت؟ 🕷️", options: ["6","8","10"], answer: 1},
        {q: "ملك الغابة؟ 🦁", options: ["فهد","أسد","دب"], answer: 1},
        {q: "كم لون في قوس قزح؟ 🌈", options: ["5","6","7"], answer: 2},
        {q: "ما هو لون التفاح الأحمر؟ 🍎", options: ["أخضر","أحمر","أصفر"], answer: 1},
        {q: "أين يعيش السمك؟ 🐠", options: ["اليابسة","البحر","السماء"], answer: 1},
        {q: "ما هو صوت الأسد؟ 🦁", options: ["مواء","زئير","نقيق"], answer: 1},
        {q: "كم عدد أركان الإسلام؟", options: ["3","4","5"], answer: 2},
        {q: "ما هي أول سورة نزلت في القرآن؟", options: ["الفاتحة","العلق","الإخلاص"], answer: 1},
        {q: "من هو أول الخلفاء الراشدين؟", options: ["عمر","عثمان","أبو بكر"], answer: 2},
        {q: "ما اسم نبي الله الذي ابتلعه الحوت؟", options: ["موسى","يونس","يوسف"], answer: 1},
        {q: "كم عدد ركعات صلاة الظهر؟", options: ["2","3","4"], answer: 2},
        {q: "ما هي السورة التي تسمى فاتحة الكتاب؟", options: ["الإخلاص","الفاتحة","الفلق"], answer: 1},
        {q: "ما هو عكس كلمة \"طويل\"؟", options: ["قصير","سمين","ضيق"], answer: 0},
        {q: "كم عدد أصابع اليد الواحدة؟", options: ["4","5","6"], answer: 1},
        {q: "ما هو لون البرتقال من الداخل؟", options: ["أخضر","برتقالي","أصفر"], answer: 1},
        {q: "ما هو الحيوان الذي يسمى سفينة الصحراء؟", options: ["حصان","جمل","فيل"], answer: 1},
        {q: "ما هو لون الدم؟", options: ["أزرق","أحمر","أخضر"], answer: 1},
        {q: "كم عدد الركعات في صلاة الفجر؟", options: ["2","3","4"], answer: 0},
        {q: "ما هو الشهر الأول في السنة الميلادية؟", options: ["فبراير","يناير","مارس"], answer: 1},
        {q: "ما هو لون العشب الطبيعي؟", options: ["أصفر","أخضر","بني"], answer: 1},
        {q: "ما هو الحيوان الذي يخاف منه الفأر؟", options: ["كلب","قطة","أرنب"], answer: 1},
        {q: "ما هو طعم الليمون؟", options: ["حلو","حامض","مالح"], answer: 1},
        {q: "ما هو عكس كلمة \"سريع\"؟", options: ["بطيء","كبير","صغير"], answer: 0},
        {q: "ما هو لون الثلج؟", options: ["أبيض","أزرق","شفاف"], answer: 0},
        {q: "ما هو صوت البقرة؟", options: ["مواء","نقيق","موو"], answer: 2},
        {q: "كم عدد أرجل الحصان؟", options: ["2","4","6"], answer: 1},
        {q: "ما هو لون السماء الصافية؟", options: ["أخضر","أزرق","أحمر"], answer: 1},
        // إضافة 100 سؤال آخر (مختصر هنا لكنك تستطيع إضافة المزيد بنفس الصيغة)
    ],
    medium: [
        {q: "عاصمة المغرب؟", options: ["الرباط","القاهرة","بيروت"], answer: 0},
        {q: "عدد لاعبي كرة القدم؟", options: ["9","11","13"], answer: 1},
        {q: "النبي الذي بنى السفينة؟", options: ["نوح","إبراهيم","موسى"], answer: 0},
        {q: "أطول نهر في العالم؟", options: ["النيل","الأمازون","الفرات"], answer: 0},
        {q: "ما هي عاصمة مصر؟", options: ["الإسكندرية","القاهرة","الجيزة"], answer: 1},
        {q: "كم عدد ألوان العلم السعودي؟", options: ["لون واحد","لونان","ثلاثة ألوان"], answer: 0},
        {q: "ما هو الكوكب الأقرب للشمس؟", options: ["الزهرة","عطارد","الأرض"], answer: 1},
        {q: "من هو الصحابي الملقب بأسد الله؟", options: ["حمزة بن عبد المطلب","خالد بن الوليد","علي بن أبي طالب"], answer: 0},
        {q: "ما هي السورة التي تسمى قلب القرآن؟", options: ["الفاتحة","الإخلاص","يس"], answer: 2},
        {q: "من هو مؤلف كتاب \"الأيام\"؟", options: ["طه حسين","عباس العقاد","نجيب محفوظ"], answer: 0},
        {q: "ما هي السورة التي ليس فيها البسملة؟", options: ["التوبة","الفاتحة","الإخلاص"], answer: 0},
        {q: "كم سنة نزل فيها القرآن؟", options: ["13","23","33"], answer: 1},
        {q: "من هو الخليفة الراشد الرابع؟", options: ["عمر","عثمان","علي"], answer: 2},
        {q: "ما هي عاصمة الأردن؟", options: ["عمان","دمشق","بيروت"], answer: 0},
        {q: "كم عدد أسنان الإنسان البالغ؟", options: ["28","30","32"], answer: 2},
        {q: "من هو مكتشف الجاذبية الأرضية؟", options: ["أينشتاين","نيوتن","جاليليو"], answer: 1},
        {q: "ما هو أكبر كوكب في المجموعة الشمسية؟", options: ["الأرض","المشتري","زحل"], answer: 1},
        {q: "ما هي اللغة الرسمية في البرازيل؟", options: ["إسبانية","برتغالية","فرنسية"], answer: 1},
        {q: "ما هو رمز عنصر الذهب في الجدول الدوري؟", options: ["Ag","Au","Fe"], answer: 1},
        {q: "من قائد معركة اليرموك؟", options: ["خالد بن الوليد","سعد بن أبي وقاص","أبو عبيدة"], answer: 0},
        {q: "ما هو أعلى جبل في الوطن العربي؟", options: ["جبل توبقال","جبل سانت كاترين","جبل لبنان"], answer: 0},
        {q: "من هو مخترع الهاتف؟", options: ["إديسون","بيل","ماركوني"], answer: 1},
        {q: "ما هي عاصمة أستراليا؟", options: ["سيدني","ملبورن","كانبرا"], answer: 2},
        {q: "كم عدد حروف اللغة العربية؟", options: ["26","28","30"], answer: 1},
        {q: "ما هو الحيوان الذي يغير لونه حسب البيئة؟", options: ["حرباء","ثعبان","ضفدع"], answer: 0},
        {q: "ما هي عاصمة تونس؟", options: ["طرابلس","تونس","الجزائر"], answer: 1},
        // أضف بقية الأسئلة المتوسطة هنا
    ],
    hard: [
        {q: "أول رئيس أمريكي؟", options: ["لينكولن","واشنطن","آدامز"], answer: 1},
        {q: "أطول جبل في العالم؟", options: ["كليمنجارو","إيفرست","إلبروس"], answer: 1},
        {q: "من هو مؤسس شركة مايكروسوفت؟", options: ["ستيف جوبز","بيل غيتس","مارك زوكربيرغ"], answer: 1},
        {q: "ما هي عملة بريطانيا؟", options: ["دولار","يورو","جنيه"], answer: 2},
        {q: "من هو أول من أسلم من الصبيان؟", options: ["علي بن أبي طالب","الزبير بن العوام","عبد الله بن عمر"], answer: 0},
        {q: "من هو أول من أسلم من الموالي؟", options: ["بلال","زيد بن حارثة","عمار بن ياسر"], answer: 1},
        {q: "ما هي السورة التي تسمى عروس القرآن؟", options: ["الرحمن","يس","الفاتحة"], answer: 0},
        {q: "من هو صاحب السفينة التي رست على جبل الجودي؟", options: ["نوح","هود","صالح"], answer: 0},
        {q: "من هو النبي الذي كان يعمل نجاراً؟", options: ["نوح","زكريا","إبراهيم"], answer: 0},
        {q: "من هو الفيلسوف اليوناني الذي علم الإسكندر الأكبر؟", options: ["سقراط","أرسطو","أفلاطون"], answer: 1},
        {q: "ما هي أسرع حيوان في العالم؟", options: ["نمر","صقر","فهد"], answer: 2},
        {q: "ما هي عملة سويسرا؟", options: ["يورو","فرنك سويسري","دينار"], answer: 1},
        {q: "من هو أول من اكتشف الدورة الدموية؟", options: ["ابن النفيس","جالينوس","ابن سينا"], answer: 0},
        {q: "كم عدد عظام الجمجمة البشرية؟", options: ["20","22","24"], answer: 1},
        {q: "من هو مؤسس علم المصريات؟", options: ["شامبليون","حسن رشدي","زاهي حواس"], answer: 0},
        {q: "ما هي أعمق نقطة في المحيطات؟", options: ["خندق ماريانا","خندق بورتوريكو","خندق اليابان"], answer: 0},
        {q: "من هو مكتشف البنسلين؟", options: ["فلمنغ","باستور","كوري"], answer: 0},
        {q: "ما هي أكبر صحراء في العالم؟", options: ["الصحراء الكبرى","صحراء الربع الخالي","صحراء غوبي"], answer: 0},
        {q: "من هو مخترع الطائرة؟", options: ["الأخوان رايت","بيل","إديسون"], answer: 0},
        {q: "ما هي أكبر جزيرة في العالم؟", options: ["أستراليا","غرينلاند","مدغشقر"], answer: 1},
        {q: "من هو مخترع التلغراف؟", options: ["مورس","بيل","إديسون"], answer: 0},
        // أضف بقية الأسئلة الصعبة هنا
    ]
};

// إضافة خاصية used لكل سؤال (لمنع التكرار)
for (let type in questionBank) {
    questionBank[type].forEach(q => { q.used = false; });
}

// ========== المتغيرات العامة ==========
let players = [];
let currentRound = 0;
let currentPlayerIndexInRound = 0;
let gameActive = true;
let answered = false;
let timerInterval;
let timeLeft = 15;
let currentQuestion = null;
let currentCorrectAnswerText = "";
const QUESTIONS_PER_PLAYER = 10;

// ========== دوال مساعدة ==========
function getPlayerType(age) {
    if (age >= 10 && age <= 15) return "easy";
    if (age >= 16 && age <= 25) return "medium";
    return "hard";
}

function getRandomQuestion(type) {
    let available = questionBank[type].filter(q => !q.used);
    if (available.length === 0) {
        questionBank[type].forEach(q => { q.used = false; });
        available = questionBank[type];
    }
    const randomIndex = Math.floor(Math.random() * available.length);
    const selected = available[randomIndex];
    selected.used = true;
    return { ...selected };
}

function shuffleOptions(question) {
    const optionsWithFlag = question.options.map((opt, idx) => ({
        text: opt,
        isCorrect: (idx === question.answer)
    }));
    for (let i = optionsWithFlag.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [optionsWithFlag[i], optionsWithFlag[j]] = [optionsWithFlag[j], optionsWithFlag[i]];
    }
    let newCorrectIndex = -1;
    const newOptions = optionsWithFlag.map((item, idx) => {
        if (item.isCorrect) newCorrectIndex = idx;
        return item.text;
    });
    return {
        q: question.q,
        options: newOptions,
        correctAnswerText: question.options[question.answer],
        correctIndex: newCorrectIndex
    };
}

// ========== دوال إدارة اللاعبين ==========
function addPlayer(name, age) {
    if (players.length >= 10) {
        showCustomAlert("❌ الحد الأقصى 10 لاعبين!");
        return false;
    }
    players.push({
        name: name,
        age: age,
        score: 0,
        type: getPlayerType(age),
        questionsAnswered: 0
    });
    renderPlayersList();
    return true;
}

function removePlayer(index) {
    players.splice(index, 1);
    renderPlayersList();
}

function renderPlayersList() {
    const list = document.getElementById('playersList');
    if (!list) return;
    if (players.length === 0) {
        list.innerHTML = '<div style="text-align: center; padding: 40px; color: #94A3B8;">👥 لا يوجد لاعبين<br>اضغط على "➕ إضافة لاعب"</div>';
    } else {
        const sorted = [...players].sort((a, b) => b.age - a.age);
        list.innerHTML = "";
        sorted.forEach((p, idx) => {
            const originalIndex = players.findIndex(orig => orig.name === p.name && orig.age === p.age);
            const div = document.createElement("div");
            div.className = "player-card";
            div.innerHTML = `
                <div class="player-info">
                    <div class="player-avatar">${p.name.charAt(0)}</div>
                    <div>
                        <div class="player-name">${p.name}</div>
                        <div class="player-age">${p.age} سنة</div>
                    </div>
                </div>
                <button class="delete-btn" data-index="${originalIndex}">🗑️</button>
            `;
            div.querySelector('.delete-btn').addEventListener('click', () => removePlayer(originalIndex));
            list.appendChild(div);
        });
    }
    const startBtn = document.getElementById('startGameBtn');
    if (startBtn) {
        if (players.length >= 2) {
            startBtn.disabled = false;
            startBtn.style.opacity = '1';
        } else {
            startBtn.disabled = true;
            startBtn.style.opacity = '0.5';
        }
    }
}

function sortPlayersByAgeDesc() {
    players.sort((a, b) => b.age - a.age);
}

// ========== دوال النوافذ المنبثقة ==========
function showCustomAlert(message) {
    const alertDialog = document.getElementById('alertDialog');
    const alertMessage = document.getElementById('alertMessage');
    if (alertDialog && alertMessage) {
        alertMessage.innerText = message;
        alertDialog.showModal();
        document.getElementById('closeAlertBtn').onclick = () => alertDialog.close();
    } else {
        alert(message);
    }
}

function showAddPlayerDialog() {
    const dialog = document.getElementById('playerDialog');
    if (dialog) {
        document.getElementById('dialogPlayerName').value = '';
        document.getElementById('dialogPlayerAge').value = '';
        dialog.showModal();
    }
}

// ========== دوال اللعبة ==========
function startGame() {
    if (players.length < 2) {
        showCustomAlert("❌ يجب إضافة لاعبين على الأقل!");
        return;
    }
    sortPlayersByAgeDesc();
    players.forEach(p => {
        p.score = 0;
        p.questionsAnswered = 0;
    });
    for (let type in questionBank) {
        questionBank[type].forEach(q => { q.used = false; });
    }
    currentRound = 0;
    currentPlayerIndexInRound = 0;
    gameActive = true;
    document.getElementById('setupScreen').style.display = 'none';
    document.getElementById('gameScreen').style.display = 'block';
    loadQuestion();
}

function loadQuestion() {
    if (!gameActive) return;
    if (timerInterval) clearInterval(timerInterval);
    answered = false;
    timeLeft = 15;

    const currentPlayer = players[currentPlayerIndexInRound];
    document.getElementById('progress').innerHTML = `الجولة ${currentRound + 1} من ${QUESTIONS_PER_PLAYER}`;
    document.getElementById('playerNameDisplay').innerHTML = `🎮 ${currentPlayer.name}`;
    document.getElementById('timer').innerHTML = timeLeft;
    document.getElementById('message').innerHTML = "";

    const raw = getRandomQuestion(currentPlayer.type);
    const shuffled = shuffleOptions(raw);
    currentQuestion = shuffled;
    currentCorrectAnswerText = shuffled.correctAnswerText;

    document.getElementById('question').innerHTML = currentQuestion.q;
    const optionsDiv = document.getElementById('options');
    optionsDiv.innerHTML = "";
    currentQuestion.options.forEach((opt, idx) => {
        const btn = document.createElement('button');
        btn.className = 'option-btn';
        btn.innerHTML = opt;
        btn.onclick = () => checkAnswer(opt, idx);
        optionsDiv.appendChild(btn);
    });

    timerInterval = setInterval(() => {
        if (!answered && timeLeft > 0 && gameActive) {
            timeLeft--;
            document.getElementById('timer').innerHTML = timeLeft;
            if (timeLeft === 0) {
                clearInterval(timerInterval);
                if (!answered && gameActive) {
                    answered = true;
                    document.getElementById('message').innerHTML = "⏰ انتهى الوقت! لا نقطة 😢";
                    document.getElementById('message').style.color = "#EF4444";
                    disableOptions();
                }
            }
        }
    }, 1000);
}

function checkAnswer(selectedText, idx) {
    if (answered || !gameActive) return;
    answered = true;
    clearInterval(timerInterval);
    const isCorrect = (selectedText === currentCorrectAnswerText);
    const options = document.querySelectorAll('.option-btn');
    let correctIndex = -1;
    for (let i = 0; i < currentQuestion.options.length; i++) {
        if (currentQuestion.options[i] === currentCorrectAnswerText) {
            correctIndex = i;
            break;
        }
    }
    if (isCorrect) {
        players[currentPlayerIndexInRound].score++;
        document.getElementById('message').innerHTML = "✅ إجابة صحيحة! +1 نقطة";
        document.getElementById('message').style.color = "#10B981";
        if (options[idx]) options[idx].classList.add('correct');
    } else {
        document.getElementById('message').innerHTML = `❌ خطأ! الإجابة الصحيحة: ${currentCorrectAnswerText}`;
        document.getElementById('message').style.color = "#EF4444";
        if (options[idx]) options[idx].classList.add('wrong');
        if (options[correctIndex]) options[correctIndex].classList.add('correct');
    }
    disableOptions();
}

function disableOptions() {
    document.querySelectorAll('.option-btn').forEach(btn => btn.style.pointerEvents = 'none');
}

function nextTurn() {
    if (!answered && timeLeft > 0 && gameActive) {
        showCustomAlert("يرجى الإجابة على السؤال أولاً!");
        return;
    }
    if (!gameActive) return;

    players[currentPlayerIndexInRound].questionsAnswered++;
    currentPlayerIndexInRound++;
    if (currentPlayerIndexInRound >= players.length) {
        currentRound++;
        currentPlayerIndexInRound = 0;
        if (currentRound >= QUESTIONS_PER_PLAYER) {
            endGame();
            return;
        }
    }
    loadQuestion();
}

function endGame() {
    gameActive = false;
    clearInterval(timerInterval);
    document.getElementById('gameScreen').style.display = 'none';
    showResults();
}

function showResults() {
    const sorted = [...players].sort((a, b) => b.score - a.score);
    const winner = sorted[0];
    const isTie = sorted.length > 1 && sorted[0].score === sorted[1].score;
    const html = `
        <div class="winner-card">
            <div class="trophy-icon">${isTie ? "🤝" : "🏆"}</div>
            <div class="winner-name">${isTie ? "تعادل!" : winner.name}</div>
            <div>${isTie ? `${winner.score} نقطة لكل` : `${winner.score} نقطة`}</div>
        </div>
        <div class="card">
            <h3>📊 النتائج النهائية</h3>
            <div class="score-list">
                ${sorted.map((p, i) => {
                    let medal = i===0 && !isTie ? "🥇" : i===1 && !isTie ? "🥈" : i===2 && !isTie ? "🥉" : `${i+1}.`;
                    return `<div class="score-row"><span class="rank">${medal}</span><span>${p.name}</span><span style="font-weight:bold;">${p.score} نقطة</span></div>`;
                }).join('')}
            </div>
            <button id="restartBtn" class="btn-primary">🔄 العب مرة أخرى</button>
        </div>
    `;
    const resultsDiv = document.getElementById('resultsScreen');
    resultsDiv.style.display = 'block';
    resultsDiv.innerHTML = html;
    document.getElementById('restartBtn').addEventListener('click', restartGame);
}

function restartGame() {
    players.forEach(p => { p.score = 0; p.questionsAnswered = 0; });
    currentRound = 0;
    currentPlayerIndexInRound = 0;
    gameActive = true;
    for (let type in questionBank) questionBank[type].forEach(q => q.used = false);
    document.getElementById('resultsScreen').style.display = 'none';
    document.getElementById('setupScreen').style.display = 'block';
    renderPlayersList();
}

// ========== ربط الأحداث عند تحميل الصفحة ==========
document.addEventListener('DOMContentLoaded', () => {
    renderPlayersList();
    document.getElementById('addPlayerBtn').addEventListener('click', showAddPlayerDialog);
    document.getElementById('startGameBtn').addEventListener('click', startGame);
    document.getElementById('nextBtn').addEventListener('click', nextTurn);

    document.getElementById('confirmAddBtn').addEventListener('click', () => {
        const name = document.getElementById('dialogPlayerName').value.trim();
        const age = parseInt(document.getElementById('dialogPlayerAge').value);
        if (!name) { showCustomAlert("❌ يرجى كتابة اسم اللاعب!"); return; }
        if (isNaN(age)) { showCustomAlert("❌ يرجى كتابة العمر!"); return; }
        if (age < 10) { showCustomAlert("❌ العمر يجب أن يكون 10 سنوات أو أكثر!"); return; }
        if (age > 70) { showCustomAlert("❌ العمر يجب أن يكون 70 سنة أو أقل!"); return; }
        addPlayer(name, age);
        document.getElementById('playerDialog').close();
    });

    document.getElementById('cancelAddBtn').addEventListener('click', () => {
        document.getElementById('playerDialog').close();
    });
});