// ========== المتغيرات العامة ==========
let players = [];
let currentRound = 0;
let currentPlayerIndexInRound = 0;
let gameActive = true;
let answered = false;
let timerInterval;
let timeLeft = 15;
let currentQuestion = null;
let currentCorrectAnswerText = "";
const QUESTIONS_PER_PLAYER = 10;

// تخزين الأسئلة بعد تحميلها من ملف JSON
let questionBank = {
    easy: [],
    medium: [],
    hard: []
};

let isLoading = true; // منع بدء اللعبة قبل تحميل الأسئلة

// ========== دالة تحميل الأسئلة من ملف JSON ==========
async function loadQuestions() {
    try {
        const response = await fetch('questions.json');
        if (!response.ok) throw new Error('فشل تحميل الأسئلة');
        const data = await response.json();
        questionBank = data;
        // إضافة خاصية used لكل سؤال (لضمان عدم التكرار)
        for (let type in questionBank) {
            questionBank[type].forEach(q => { q.used = false; });
        }
        isLoading = false;
        console.log("تم تحميل الأسئلة بنجاح");
        // تفعيل واجهة اللعبة
        document.getElementById('startGameBtn').disabled = false;
    } catch (error) {
        console.error(error);
        showCustomAlert("⚠️ فشل تحميل الأسئلة. تأكد من اتصالك بالإنترنت وأعد تشغيل التطبيق.");
        isLoading = true;
    }
}

// ========== نوافذ منبثقة مخصصة ==========
function showCustomAlert(message) {
    const alertDialog = document.getElementById('alertDialog');
    const alertMessage = document.getElementById('alertMessage');
    if (alertDialog) {
        alertMessage.innerText = message;
        alertDialog.showModal();
        document.getElementById('closeAlertBtn').onclick = () => alertDialog.close();
    } else {
        alert(message);
    }
}

// استبدال alert الافتراضية لضمان العمل داخل WebView
window.alert = showCustomAlert;

// ========== دوال إدارة اللاعبين ==========
function getPlayerType(age) {
    if (age >= 10 && age <= 15) return "easy";
    if (age >= 16 && age <= 25) return "medium";
    return "hard";
}

function addPlayer(name, age) {
    if (players.length >= 10) {
        showCustomAlert("❌ الحد الأقصى 10 لاعبين!");
        return false;
    }
    players.push({
        name: name,
        age: age,
        score: 0,
        type: getPlayerType(age),
        questionsAnswered: 0
    });
    renderPlayersList();
    return true;
}

function removePlayer(index) {
    players.splice(index, 1);
    renderPlayersList();
}

function renderPlayersList() {
    const list = document.getElementById('playersList');
    if (players.length === 0) {
        list.innerHTML = '<div style="text-align: center; padding: 40px; color: #94A3B8;">👥 لا يوجد لاعبين<br>اضغط على "➕ إضافة لاعب"</div>';
    } else {
        const sortedForDisplay = [...players].sort((a, b) => b.age - a.age);
        list.innerHTML = "";
        sortedForDisplay.forEach((p, idx) => {
            const originalIndex = players.findIndex(orig => orig.name === p.name && orig.age === p.age);
            const div = document.createElement("div");
            div.className = "player-card";
            div.innerHTML = `
                <div class="player-info">
                    <div class="player-avatar">${p.name.charAt(0)}</div>
                    <div>
                        <div class="player-name">${p.name}</div>
                        <div class="player-age">${p.age} سنة</div>
                    </div>
                </div>
                <button class="delete-btn" data-index="${originalIndex}">🗑️</button>
            `;
            div.querySelector('.delete-btn').addEventListener('click', () => removePlayer(originalIndex));
            list.appendChild(div);
        });
    }
    const startBtn = document.getElementById('startGameBtn');
    if (players.length >= 2 && !isLoading) {
        startBtn.disabled = false;
        startBtn.style.opacity = '1';
    } else {
        startBtn.disabled = true;
        startBtn.style.opacity = '0.5';
    }
}

function sortPlayersByAgeDesc() {
    players.sort((a, b) => b.age - a.age);
}

// نافذة إضافة لاعب
function showAddPlayerDialog() {
    const dialog = document.getElementById('playerDialog');
    const nameInput = document.getElementById('dialogPlayerName');
    const ageInput = document.getElementById('dialogPlayerAge');
    nameInput.value = '';
    ageInput.value = '';
    dialog.showModal();
}

// ========== دوال اللعبة ==========
function selectRandomQuestion(type) {
    let available = questionBank[type].filter(q => !q.used);
    if (available.length === 0) {
        // إعادة تعيين used لجميع الأسئلة (جولة جديدة)
        questionBank[type].forEach(q => { q.used = false; });
        available = questionBank[type];
    }
    const randomIndex = Math.floor(Math.random() * available.length);
    const selected = available[randomIndex];
    selected.used = true;
    return { ...selected };
}

function shuffleOptions(question) {
    const optionsWithFlag = question.options.map((opt, idx) => ({
        text: opt,
        isCorrect: (idx === question.answer)
    }));
    for (let i = optionsWithFlag.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [optionsWithFlag[i], optionsWithFlag[j]] = [optionsWithFlag[j], optionsWithFlag[i]];
    }
    let newCorrectIndex = -1;
    const newOptions = optionsWithFlag.map((item, idx) => {
        if (item.isCorrect) newCorrectIndex = idx;
        return item.text;
    });
    return {
        q: question.q,
        options: newOptions,
        correctAnswerText: question.options[question.answer],
        correctIndex: newCorrectIndex
    };
}

function startGame() {
    if (isLoading) {
        showCustomAlert("⏳ يرجى الانتظار حتى تحميل الأسئلة...");
        return;
    }
    if (players.length < 2) {
        showCustomAlert("❌ يجب إضافة لاعبين على الأقل!");
        return;
    }
    sortPlayersByAgeDesc();
    players.forEach(p => {
        p.score = 0;
        p.questionsAnswered = 0;
    });
    // إعادة تعيين used لكل الأسئلة
    for (let type in questionBank) {
        questionBank[type].forEach(q => { q.used = false; });
    }
    currentRound = 0;
    currentPlayerIndexInRound = 0;
    gameActive = true;
    document.getElementById('setupScreen').style.display = 'none';
    document.getElementById('gameScreen').style.display = 'block';
    loadQuestion();
}

function loadQuestion() {
    if (!gameActive) return;
    if (timerInterval) clearInterval(timerInterval);
    answered = false;
    timeLeft = 15;

    const currentPlayer = players[currentPlayerIndexInRound];
    document.getElementById('progress').innerHTML = `الجولة ${currentRound + 1} من ${QUESTIONS_PER_PLAYER}`;
    document.getElementById('playerNameDisplay').innerHTML = `🎮 ${currentPlayer.name}`;
    document.getElementById('timer').innerHTML = timeLeft;
    document.getElementById('message').innerHTML = "";

    let rawQuestion = selectRandomQuestion(currentPlayer.type);
    let shuffled = shuffleOptions(rawQuestion);
    currentQuestion = shuffled;
    currentCorrectAnswerText = shuffled.correctAnswerText;

    document.getElementById('question').innerHTML = currentQuestion.q;
    const optionsDiv = document.getElementById('options');
    optionsDiv.innerHTML = "";
    currentQuestion.options.forEach((opt, idx) => {
        const btn = document.createElement('button');
        btn.className = 'option-btn';
        btn.innerHTML = opt;
        btn.onclick = () => checkAnswer(opt, idx);
        optionsDiv.appendChild(btn);
    });

    timerInterval = setInterval(() => {
        if (!answered && timeLeft > 0 && gameActive) {
            timeLeft--;
            document.getElementById('timer').innerHTML = timeLeft;
            if (timeLeft === 0) {
                clearInterval(timerInterval);
                if (!answered && gameActive) {
                    answered = true;
                    document.getElementById('message').innerHTML = "⏰ انتهى الوقت! لا نقطة 😢";
                    document.getElementById('message').style.color = "#EF4444";
                    disableOptions();
                }
            }
        }
    }, 1000);
}

function checkAnswer(selectedOptionText, selectedIndex) {
    if (answered || !gameActive) return;
    answered = true;
    clearInterval(timerInterval);
    const isCorrect = (selectedOptionText === currentCorrectAnswerText);
    const options = document.querySelectorAll('.option-btn');
    let correctOptionIndex = -1;
    for (let i = 0; i < currentQuestion.options.length; i++) {
        if (currentQuestion.options[i] === currentCorrectAnswerText) {
            correctOptionIndex = i;
            break;
        }
    }
    if (isCorrect) {
        players[currentPlayerIndexInRound].score++;
        document.getElementById('message').innerHTML = "✅ إجابة صحيحة! +1 نقطة";
        document.getElementById('message').style.color = "#10B981";
        if (options[selectedIndex]) options[selectedIndex].classList.add('correct');
    } else {
        document.getElementById('message').innerHTML = `❌ خطأ! الإجابة الصحيحة: ${currentCorrectAnswerText}`;
        document.getElementById('message').style.color = "#EF4444";
        if (options[selectedIndex]) options[selectedIndex].classList.add('wrong');
        if (options[correctOptionIndex]) options[correctOptionIndex].classList.add('correct');
    }
    disableOptions();
}

function disableOptions() {
    const options = document.querySelectorAll('.option-btn');
    options.forEach(opt => {
        opt.style.pointerEvents = 'none';
    });
}

function nextTurn() {
    if (!answered && timeLeft > 0 && gameActive) {
        showCustomAlert("يرجى الإجابة على السؤال أولاً!");
        return;
    }
    if (!gameActive) return;

    players[currentPlayerIndexInRound].questionsAnswered++;
    currentPlayerIndexInRound++;

    if (currentPlayerIndexInRound >= players.length) {
        currentRound++;
        currentPlayerIndexInRound = 0;
        if (currentRound >= QUESTIONS_PER_PLAYER) {
            endGame();
            return;
        }
    }
    loadQuestion();
}

function endGame() {
    gameActive = false;
    clearInterval(timerInterval);
    document.getElementById('gameScreen').style.display = 'none';
    showResultsScreen();
}

function showResultsScreen() {
    const sortedPlayers = [...players].sort((a, b) => b.score - a.score);
    const winner = sortedPlayers[0];
    const isTie = sortedPlayers.length > 1 && sortedPlayers[0].score === sortedPlayers[1].score;

    const resultsHTML = `
        <div class="winner-card">
            <div class="trophy-icon">${isTie ? "🤝" : "🏆"}</div>
            <div class="winner-name">${isTie ? "تعادل!" : winner.name}</div>
            <div style="font-size: 18px;">${isTie ? `${winner.score} نقطة لكل منهما` : `${winner.score} نقطة`}</div>
        </div>
        <div class="card">
            <h3 style="margin-bottom: 16px;">📊 النتائج النهائية</h3>
            <div class="score-list">
                ${sortedPlayers.map((player, idx) => {
                    let medal = "";
                    if (idx === 0 && !isTie) medal = "🥇";
                    else if (idx === 1 && !isTie) medal = "🥈";
                    else if (idx === 2 && !isTie) medal = "🥉";
                    else medal = `${idx + 1}.`;
                    return `
                        <div class="score-row">
                            <span class="rank">${medal}</span>
                            <span>${player.name}</span>
                            <span style="font-weight: 700; color: #6366F1;">${player.score} نقطة</span>
                        </div>
                    `;
                }).join('')}
            </div>
            <button id="restartBtn" class="btn-primary" style="margin-top: 16px;">🔄 العب مرة أخرى</button>
        </div>
    `;
    document.getElementById('resultsScreen').style.display = 'block';
    document.getElementById('resultsScreen').innerHTML = resultsHTML;
    document.getElementById('restartBtn').addEventListener('click', restartFromResults);
}

function restartFromResults() {
    players.forEach(p => {
        p.score = 0;
        p.questionsAnswered = 0;
    });
    currentRound = 0;
    currentPlayerIndexInRound = 0;
    gameActive = true;
    // إعادة تعيين used
    for (let type in questionBank) {
        questionBank[type].forEach(q => { q.used = false; });
    }
    document.getElementById('resultsScreen').style.display = 'none';
    document.getElementById('setupScreen').style.display = 'block';
    renderPlayersList();
}

// ========== إعداد الأحداث عند تحميل الصفحة ==========
document.addEventListener('DOMContentLoaded', () => {
    loadQuestions(); // تحميل الأسئلة من ملف JSON
    renderPlayersList();

    document.getElementById('addPlayerBtn').addEventListener('click', showAddPlayerDialog);
    document.getElementById('startGameBtn').addEventListener('click', startGame);
    document.getElementById('nextBtn').addEventListener('click', nextTurn);

    document.getElementById('confirmAddBtn').addEventListener('click', () => {
        const name = document.getElementById('dialogPlayerName').value.trim();
        const age = parseInt(document.getElementById('dialogPlayerAge').value);
        if (!name) {
            showCustomAlert("❌ يرجى كتابة اسم اللاعب!");
            return;
        }
        if (isNaN(age)) {
            showCustomAlert("❌ يرجى كتابة العمر!");
            return;
        }
        if (age < 10) {
            showCustomAlert("❌ العمر يجب أن يكون 10 سنوات أو أكثر!");
            return;
        }
        if (age > 70) {
            showCustomAlert("❌ العمر يجب أن يكون 70 سنة أو أقل!");
            return;
        }
        addPlayer(name, age);
        document.getElementById('playerDialog').close();
    });

    document.getElementById('cancelAddBtn').addEventListener('click', () => {
        document.getElementById('playerDialog').close();
    });
});